//O principal objetivo deste desafio é fortalecer suas habilidades em lógica de programação. Aqui você deverá desenvolver a lógica para resolver o problema.

const amigos = [];

function adicionarAmigo() {  
    const campoNome = document.getElementById("amigo");
    const valor = campoNome.value;
    if (valor == '') {
        alert('O campo esta vazio. Digite algum nome!');
    } else {
    amigos.push(valor);
    campoNome.value = '';
    console.log(amigos);
    atualizarLista();
    }
}

// Esta linha declara uma função chamada atualizarLista. Funções são blocos de código 
// projetados para executar uma tarefa específica quando chamados.
function atualizarLista() {
    //Esta linha utiliza document.getElementById para obter uma referência ao elemento do DOM (Document Object Model) com o ID listaAmigos. 
    // A referência é armazenada na variável lista. Isso significa que lista agora aponta para o elemento <ul> ou <ol> (ou qualquer elemento) com o ID listaAmigos.
    const lista = document.getElementById("listaAmigos");
    //Esta linha redefine o conteúdo HTML interno do elemento lista para uma string vazia. 
    // Isso efetivamente limpa a lista atual, removendo todos os seus itens. 
    // É útil para garantir que a lista seja atualizada a partir do zero.
    lista.innerHTML = ''; // Limpando a lista atual
    // Criando itens de lista para cada elemento do array
    amigos.forEach(item => {
        const listItem = document.createElement("li");
        listItem.textContent = item;
        lista.appendChild(listItem);
});
}


function sortearAmigo(){
    const quantidadeNomes = amigos.length;
    const nomeAleatorio = Math.floor(Math.random() * (0 + quantidadeNomes));
    const lista2 = document.getElementById("listaAmigos");
    lista2.innerHTML = '';
    const listItem2 = document.createElement("li");
    listItem2.textContent = amigos[nomeAleatorio];
    lista2.appendChild(listItem2);
}


